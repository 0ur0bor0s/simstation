package simstation;

/*
 * Edit history:
 *   Quang-Duy, 03/30: created
*/

public enum Heading {
	NORTH,
	SOUTH,
	EAST,
	WEST;
}
