package prison;
/*
 * created 4/5: Anmol Singh
 */
public enum Strategy{
	ALWAYSCHEAT,
	ALWAYSCOOP,
	RANDOM,
	FOLLOW;
}
